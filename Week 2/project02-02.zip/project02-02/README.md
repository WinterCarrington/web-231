# WEB 231 Enterprise JavaScript I
## Contributors
- Instructor's Name: [Richard Krasso]
- Your Name: [Lantha Wade]


